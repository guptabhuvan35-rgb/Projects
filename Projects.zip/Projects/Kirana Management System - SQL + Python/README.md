# Kirana Store Management System

**Author:** Bhuvan Gupta
**Generated on:** 2025-11-13T14:40:24.551363 UTC

## Overview
Complete end-to-end Kirana store project using SQLite and Python. This package contains:

- `kirana_schema_fixed.sql` — Corrected SQLite SQL schema with seed data.
- `Kirana_Store_Management_Full.ipynb` — Full Jupyter notebook (runnable) implementing inventory, sales, and reporting.
- `README.md` — This file.

## Quick start
1. Unzip the package.
2. (Optional) Inspect or run the SQL to create the DB:
   - SQLite: `sqlite3 kirana_store.db < kirana_schema_fixed.sql`
   - Or run the notebook which will run the SQL automatically if the SQL file is present.
3. Open `Kirana_Store_Management_Full.ipynb` in Jupyter and run all cells.

## Notes
- The SQL file is SQLite-compatible and tested for syntax correctness.
- The notebook includes defensive checks (stock validation, atomic transactions).
