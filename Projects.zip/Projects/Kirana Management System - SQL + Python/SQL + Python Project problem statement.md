## **Top Mentor - Data Science with Gen AI Certification =**

## **List of Assignments and Projects**



### **\*\*PROJECTS\*\***



#### 1\. Python (Python + Database)

#### Build any business application. Examples:-



--> Library Management System: LMS allows you to :

                                ----> Admin Process: Add Books, Remove Books

                                ----> User Process: Register, Borrow the book, Return the book

--> Kirana Store management System:

                       ---> Process: Adding inventory to the database(Along with quantity \& price)

                       ---> Sale: Quantity \& price

                       ---> Daily Sales Report: How many products, quantity they sold \& profit they made





2\.

