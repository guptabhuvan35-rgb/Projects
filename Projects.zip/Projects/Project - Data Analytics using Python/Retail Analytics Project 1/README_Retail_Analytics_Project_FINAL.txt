Retail Analytics Project

Student: Bhuvan Gupta

This is the final, fully tested version of the Retail Analytics Project using Python in the PyCharm Jupyter environment.

Dataset Location
E:\Top Mentor - Data Science\Projects\Project - Data Analytics using Python\Retail Analytics Project 1\Superstore.csv

How to Run
1. Open this notebook in PyCharm's Jupyter Notebook view.
2. Run each cell sequentially (Shift + Enter).
3. All outputs and plots appear inline — no CSV or external file generation.

Python Libraries Used
- pandas
- numpy
- matplotlib

---
End of README
